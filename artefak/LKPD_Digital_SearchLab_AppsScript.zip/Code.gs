/**
 * LKPD Digital Search Lab — Informatika Kelas X
 * Gunakan sebagai script yang terikat (container-bound) pada Google Sheets.
 * Jalankan setupSheets() satu kali sebelum deploy sebagai Web App.
 */
const SHEET_GROUP = 'Hasil Kelompok';
const SHEET_EXIT = 'Exit Ticket';
const PROP_SPREADSHEET_ID = 'SEARCHLAB_SPREADSHEET_ID';

const GROUP_HEADERS = [
  'Waktu Kirim', 'Kelas', 'Nama Kelompok', 'Anggota dan Peran', 'Konteks Topik',
  'Pertanyaan Penelusuran', 'Query Awal', 'Query Optimal',
  'Operator 1', 'Fungsi Operator 1', 'Operator 2', 'Fungsi Operator 2',
  'Google - Relevan Top-5 Awal', 'Google - Waktu Awal (detik)', 'Google - Judul/Domain Awal',
  'Google - Relevan Top-5 Optimal', 'Google - Waktu Optimal (detik)', 'Google - Judul/Domain Optimal',
  'Bing - Relevan Top-5 Awal', 'Bing - Waktu Awal (detik)', 'Bing - Judul/Domain Awal',
  'Bing - Relevan Top-5 Optimal', 'Bing - Waktu Optimal (detik)', 'Bing - Judul/Domain Optimal',
  'Yahoo - Relevan Top-5 Awal', 'Yahoo - Waktu Awal (detik)', 'Yahoo - Judul/Domain Awal',
  'Yahoo - Relevan Top-5 Optimal', 'Yahoo - Waktu Optimal (detik)', 'Yahoo - Judul/Domain Optimal',
  'Analisis Perubahan', 'Keterbatasan Pengamatan', 'Mesin Pencari Rekomendasi', 'Bukti Pendukung 1', 'Bukti Pendukung 2'
];

const EXIT_HEADERS = [
  'Waktu Kirim', 'Nama Peserta Didik', 'Kelas', 'Nama Kelompok',
  'Soal 1 - Browser/Search Engine', 'Soal 2 - Frasa Tepat', 'Soal 3 - PDF',
  'Soal 4 - Domain', 'Soal 5 - Perbandingan Adil', 'Skor (0-100)',
  'Operator Paling Membantu', 'Bukti Query Lebih Baik', 'Hal yang Masih Membingungkan',
  'Strategi yang Akan Digunakan Berikutnya'
];

function doGet() {
  ensureSheets_();
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Search Lab | LKPD Digital Informatika')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Search Lab')
    .addItem('Siapkan/Periksa Sheet LKPD', 'setupSheets')
    .addToUi();
}

function setupSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Buka Apps Script dari Google Sheets yang akan digunakan sebagai basis data.');
  PropertiesService.getScriptProperties().setProperty(PROP_SPREADSHEET_ID, ss.getId());
  ensureSheet_(ss, SHEET_GROUP, GROUP_HEADERS);
  ensureSheet_(ss, SHEET_EXIT, EXIT_HEADERS);
  ss.toast('Sheet Search Lab siap digunakan.', 'Search Lab', 5);
  return 'Siap: ' + ss.getUrl();
}

function getWebAppInfo() {
  const ss = getSpreadsheet_();
  return { spreadsheetName: ss.getName(), spreadsheetUrl: ss.getUrl() };
}

function submitGroup(data) {
  validateGroup_(data);
  const ss = getSpreadsheet_();
  const sh = ensureSheet_(ss, SHEET_GROUP, GROUP_HEADERS);
  const row = [
    new Date(), safeText_(data.kelas, 50), safeText_(data.namaKelompok, 100), safeText_(data.anggota, 500),
    safeText_(data.topik, 100), safeText_(data.pertanyaan, 500), safeText_(data.queryAwal, 300), safeText_(data.queryOptimal, 500),
    safeText_(data.operator1, 100), safeText_(data.fungsi1, 250), safeText_(data.operator2, 100), safeText_(data.fungsi2, 250),
    safeNumber_(data.gAwalRelevan, 0, 5), safeNumber_(data.gAwalWaktu, 0, 999), safeText_(data.gAwalSumber, 500),
    safeNumber_(data.gOptimalRelevan, 0, 5), safeNumber_(data.gOptimalWaktu, 0, 999), safeText_(data.gOptimalSumber, 500),
    safeNumber_(data.bAwalRelevan, 0, 5), safeNumber_(data.bAwalWaktu, 0, 999), safeText_(data.bAwalSumber, 500),
    safeNumber_(data.bOptimalRelevan, 0, 5), safeNumber_(data.bOptimalWaktu, 0, 999), safeText_(data.bOptimalSumber, 500),
    safeOptionalNumber_(data.yAwalRelevan, 0, 5), safeOptionalNumber_(data.yAwalWaktu, 0, 999), safeText_(data.yAwalSumber, 500),
    safeOptionalNumber_(data.yOptimalRelevan, 0, 5), safeOptionalNumber_(data.yOptimalWaktu, 0, 999), safeText_(data.yOptimalSumber, 500),
    safeText_(data.analisis, 1000), safeText_(data.keterbatasan, 800), safeText_(data.rekomendasi, 100),
    safeText_(data.bukti1, 500), safeText_(data.bukti2, 500)
  ];
  sh.appendRow(row);
  return { ok: true, message: 'Hasil kelompok berhasil disimpan. Pastikan satu anggota kelompok menyampaikan simpulan saat sesi berbagi.' };
}

function submitExitTicket(data) {
  validateExit_(data);
  const key = { q1: 'B', q2: 'C', q3: 'A', q4: 'B', q5: 'C' };
  let score = 0;
  ['q1', 'q2', 'q3', 'q4', 'q5'].forEach(k => { if (String(data[k]) === key[k]) score += 20; });
  const ss = getSpreadsheet_();
  const sh = ensureSheet_(ss, SHEET_EXIT, EXIT_HEADERS);
  sh.appendRow([
    new Date(), safeText_(data.nama, 150), safeText_(data.kelas, 50), safeText_(data.kelompok, 100),
    safeText_(data.q1, 10), safeText_(data.q2, 10), safeText_(data.q3, 10), safeText_(data.q4, 10), safeText_(data.q5, 10), score,
    safeText_(data.operatorMembantu, 300), safeText_(data.bukti, 800), safeText_(data.bingung, 800), safeText_(data.strategi, 800)
  ]);
  return { ok: true, score: score, message: 'Exit ticket tersimpan. Gunakan hasil ini untuk melihat bagian yang sudah dipahami dan yang perlu diperkuat.' };
}

function validateGroup_(d) {
  if (!d || !String(d.kelas || '').trim() || !String(d.namaKelompok || '').trim() || !String(d.anggota || '').trim()) {
    throw new Error('Lengkapi kelas, nama kelompok, dan anggota beserta perannya.');
  }
  if (!String(d.topik || '').trim() || !String(d.pertanyaan || '').trim() || !String(d.queryAwal || '').trim() || !String(d.queryOptimal || '').trim()) {
    throw new Error('Lengkapi pertanyaan penelusuran, query awal, dan query yang dioptimalkan.');
  }
  if (!String(d.operator1 || '').trim() || !String(d.operator2 || '').trim() || d.operator1 === d.operator2) {
    throw new Error('Pilih dua operator yang berbeda dan tuliskan fungsi keduanya.');
  }
  ['gAwalRelevan','gAwalWaktu','gOptimalRelevan','gOptimalWaktu','bAwalRelevan','bAwalWaktu','bOptimalRelevan','bOptimalWaktu'].forEach(k => {
    const n = Number(d[k]);
    if (d[k] === '' || d[k] === null || !Number.isFinite(n)) throw new Error('Lengkapi seluruh data wajib untuk Google dan Bing.');
  });
  if (!String(d.gAwalSumber || '').trim() || !String(d.gOptimalSumber || '').trim() || !String(d.bAwalSumber || '').trim() || !String(d.bOptimalSumber || '').trim()) {
    throw new Error('Tuliskan judul singkat atau domain sumber relevan untuk setiap pengujian Google dan Bing.');
  }
  safeNumber_(d.gAwalRelevan, 0, 5); safeNumber_(d.gOptimalRelevan, 0, 5);
  safeNumber_(d.bAwalRelevan, 0, 5); safeNumber_(d.bOptimalRelevan, 0, 5);
  safeNumber_(d.gAwalWaktu, 0, 999); safeNumber_(d.gOptimalWaktu, 0, 999);
  safeNumber_(d.bAwalWaktu, 0, 999); safeNumber_(d.bOptimalWaktu, 0, 999);
  if (!String(d.analisis || '').trim() || !String(d.rekomendasi || '').trim() || !String(d.bukti1 || '').trim() || !String(d.bukti2 || '').trim()) {
    throw new Error('Lengkapi analisis perubahan, rekomendasi, serta dua bukti pendukung.');
  }
}

function validateExit_(d) {
  if (!d || !String(d.nama || '').trim() || !String(d.kelas || '').trim()) throw new Error('Isi nama dan kelas terlebih dahulu.');
  ['q1','q2','q3','q4','q5'].forEach(k => {
    if (!['A','B','C','D'].includes(String(d[k] || ''))) throw new Error('Jawab kelima soal pilihan ganda.');
  });
  if (!String(d.operatorMembantu || '').trim() || !String(d.bukti || '').trim() || !String(d.bingung || '').trim() || !String(d.strategi || '').trim()) {
    throw new Error('Lengkapi empat isian refleksi singkat.');
  }
}

function getSpreadsheet_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty(PROP_SPREADSHEET_ID);
  if (id) return SpreadsheetApp.openById(id);
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (!active) throw new Error('Basis data belum disiapkan. Buka editor Apps Script dari Google Sheets, lalu jalankan setupSheets().');
  props.setProperty(PROP_SPREADSHEET_ID, active.getId());
  return active;
}

function ensureSheets_() {
  const ss = getSpreadsheet_();
  ensureSheet_(ss, SHEET_GROUP, GROUP_HEADERS);
  ensureSheet_(ss, SHEET_EXIT, EXIT_HEADERS);
}

function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.getRange(1, 1, 1, headers.length)
      .setBackground('#17324D').setFontColor('#FFFFFF').setFontWeight('bold')
      .setWrap(true).setVerticalAlignment('middle');
    sh.setFrozenRows(1);
    sh.setRowHeight(1, 42);
    sh.autoResizeColumns(1, Math.min(headers.length, 10));
    if (headers.length > 10) sh.setColumnWidths(11, headers.length - 10, 180);
    sh.setColumnWidth(1, 155);
  }
  return sh;
}

function safeText_(value, maxLength) {
  let s = String(value == null ? '' : value).trim().slice(0, maxLength || 1000);
  // Prevent user input from being interpreted as a spreadsheet formula.
  if (/^[=+\-@]/.test(s)) s = "'" + s;
  return s;
}
function safeNumber_(value, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < min || n > max) throw new Error('Angka di luar batas yang diperbolehkan.');
  return n;
}
function safeOptionalNumber_(value, min, max) {
  if (value === '' || value === null || typeof value === 'undefined') return '';
  return safeNumber_(value, min, max);
}
